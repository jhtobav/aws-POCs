import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jhtobav',
    application_name='crossaccountcognito',
    app_uid='jfpr8DsHmHR68pHYJ5',
    org_uid='2NZSbkGJ39bZBtX8ww',
    deployment_uid='ed22702d-f760-41cc-a7fd-1dffe03df4d5',
    service_name='crossaccountcognito',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'crossaccountcognito-dev-signup', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('signup.sign_up')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
