import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jhtobav',
    application_name='stepfunctionspoc',
    app_uid='DpzDlW67BbNQ37jfgG',
    org_uid='2NZSbkGJ39bZBtX8ww',
    deployment_uid='d3280371-cec5-44b5-9ac8-50d5109951e1',
    service_name='stepfunctionspoc',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'stepfunctionspoc-dev-funcion_dos', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('funcion_dos.funcion_dos')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
